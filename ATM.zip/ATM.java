import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ATM {
    private static String name;
    private static int balance = 0;
    private static String accnumber;
    private static List<String> history = new ArrayList<>();

    public static void main(String[] args) {
        homepage();
    }

    private static void homepage() {
        System.out.println("WELCOME TO ATM INTERFACE");
        System.out.println("--------------------------");
        System.out.println("Select option:");
        System.out.println("1. Register");
        System.out.println("2. Exit");
        int choice = getIntInput("Enter choice: ");
        switch (choice) {
            case 1:
                BankAccount.register();
                break;
            case 2:
                System.exit(0);
                break;
            default:
                System.out.println("Select a value only from the given options:");
                homepage();
        }
    }

    private static void prompt() {
        System.out.println("WELCOME " + name + "! TO ATM SYSTEM");
        System.out.println("---------------------");
        System.out.println("Select option: ");
        System.out.println("1. Withdraw");
        System.out.println("2. Deposit");
        System.out.println("3. Transfer");
        System.out.println("4. Check balance");
        System.out.println("5. Transaction History");
        System.out.println("6. Exit");
        int choice = getIntInput("Enter your choice: ");
        switch (choice) {
            case 1:
                Transaction.withdraw();
                break;
            case 2:
                Transaction.deposit();
                break;
            case 3:
                Transaction.transfer();
                break;
            case 4:
                Check.checkBalance();
                break;
            case 5:
                History.transactionHistory();
                break;
            case 6:
                System.exit(0);
                break;
        }
    }

    private static int getIntInput(String prompt) {
        Scanner sc = new Scanner(System.in);
        System.out.print(prompt);
        return sc.nextInt();
    }

    public static void updateBalance(int amount) {
        balance += amount;
    }

    public static void showBalance() {
        System.out.println(balance);
    }
}