import java.util.Scanner;

public class BankAccount {
    public static void register() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your name:");
        ATM.name = sc.nextLine();
        System.out.println("Enter username:");
        String user = sc.nextLine();
        System.out.println("Enter password:");
        String pass = sc.nextLine();
        System.out.println("Enter your Account number:");
        ATM.accnumber = sc.nextLine();
        System.out.println("REGISTRATION SUCCESSFULLY!");
        ATM.prompt();
    }
}