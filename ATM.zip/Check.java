public class Check {
    public static void checkBalance() {
        System.out.println("Available balance:");
        ATM.showBalance();
        ATM.prompt();
    }
}