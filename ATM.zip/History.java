public class History {
    public static void transactionHistory() {
        System.out.println("Transaction History:");
        // TO DO: implement transaction history logic
        ATM.prompt();
    }
}