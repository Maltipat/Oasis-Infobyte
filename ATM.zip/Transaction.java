import java.util.Scanner;

public class Transaction {
    public static void withdraw() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter amount to withdraw:");
        int amount = sc.nextInt();
        if (amount > ATM.balance) {
            System.out.println("Insufficient balance");
        } else {
            ATM.updateBalance(-amount);
            System.out.println("Amount withdrawn successfully");
        }
        ATM.prompt();
    }

    public static void deposit() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter amount to deposit:");
        int amount = sc.nextInt();
        ATM.updateBalance(amount);
        System.out.println("Amount deposited successfully");
        ATM.prompt();
    }

    public static void transfer() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter amount to transfer:");
        int amount = sc.nextInt();
        System.out.println("Enter recipient's account number:");
        String recipient = sc.next();
        if (amount > ATM.balance) {
            System.out.println("Insufficient balance");
        } else {
            ATM.updateBalance(-amount);
            System.out.println("Amount transferred successfully");
        }
        ATM.prompt();
    }
}