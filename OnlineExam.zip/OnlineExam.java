import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

// Main class to start the application
public class OnlineExam {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(Login::new);
    }
}

// Class for Login Form
class Login extends JFrame implements ActionListener {
    private JButton loginButton, registerButton, resetButton;
    private JLabel userLabel, passLabel, messageLabel;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private int loginAttempts = 0;
    private final Map<String, String> credentials = new HashMap<>();
    private RegisterForm registerForm;
    private ResetPasswordForm resetPasswordForm;

    // Constructor to initialize the Login form
    public Login() {
        setTitle("Login Form");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(51, 153, 255));

        userLabel = new JLabel("Username:");
        userLabel.setForeground(Color.WHITE);
        userLabel.setBounds(50, 30, 80, 25);
        panel.add(userLabel);

        usernameField = new JTextField(20);
        usernameField.setBounds(150, 30, 200, 25);
        panel.add(usernameField);

        passLabel = new JLabel("Password:");
        passLabel.setForeground(Color.WHITE);
        passLabel.setBounds(50, 70, 80, 25);
        panel.add(passLabel);

        passwordField = new JPasswordField(20);
        passwordField.setBounds(150, 70, 200, 25);
        panel.add(passwordField);

        loginButton = new JButton("Login");
        loginButton.setBounds(50, 110, 80, 30);
        panel.add(loginButton);

        registerButton = new JButton("Register");
        registerButton.setBounds(150, 110, 100, 30);
        panel.add(registerButton);

        resetButton = new JButton("Reset Password");
        resetButton.setBounds(270, 110, 100, 30);
        panel.add(resetButton);

        messageLabel = new JLabel();
        messageLabel.setBounds(50, 160, 320, 25);
        panel.add(messageLabel);

        loginButton.addActionListener(this);
        registerButton.addActionListener(this);
        resetButton.addActionListener(this);

        credentials.put("user1", hashPassword("password1"));
        credentials.put("user2", hashPassword("password2"));

        add(panel);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == loginButton) {
            handleLogin();
        } else if (ae.getSource() == registerButton) {
            openRegisterForm();
        } else if (ae.getSource() == resetButton) {
            openResetPasswordForm();
        }
    }

    private void handleLogin() {
        String username = usernameField.getText();
        String password = String.valueOf(passwordField.getPassword());

        if (credentials.containsKey(username) && credentials.get(username).equals(hashPassword(password))) {
            JOptionPane.showMessageDialog(this, "Login Successful!");
            dispose();
            new OnlineTestBegin(username);
        } else {
            loginAttempts++;
            if (loginAttempts >= 3) {
                JOptionPane.showMessageDialog(this, "Login Attempts Exceeded. Please try again later.");
                System.exit(0);
            } else {
                messageLabel.setForeground(Color.RED);
                messageLabel.setText("Invalid username or password. Please try again.");
            }
        }
    }

    private void openRegisterForm() {
        registerForm = new RegisterForm(this);
        registerForm.setVisible(true);
    }

    private void openResetPasswordForm() {
        resetPasswordForm = new ResetPasswordForm(this);
        resetPasswordForm.setVisible(true);
    }

    void addCredentials(String username, String password) {
        credentials.put(username, hashPassword(password));
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashedBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error hashing password", e);
        }
    }
}

// Class for Registration Form
class RegisterForm extends JFrame implements ActionListener {
    private final JTextField usernameField;
    private final JPasswordField passwordField;
    private final Login parent;

    public RegisterForm(Login parent) {
        this.parent = parent;

        setTitle("Register Form");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(300, 200);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(null);

        JLabel userLabel = new JLabel("Username:");
        userLabel.setBounds(30, 30, 80, 25);
        panel.add(userLabel);

        usernameField = new JTextField(20);
        usernameField.setBounds(120, 30, 150, 25);
        panel.add(usernameField);

        JLabel passLabel = new JLabel("Password:");
        passLabel.setBounds(30, 70, 80, 25);
        panel.add(passLabel);

        passwordField = new JPasswordField(20);
        passwordField.setBounds(120, 70, 150, 25);
        panel.add(passwordField);

        JButton registerButton = new JButton("Register");
        registerButton.setBounds(100, 120, 100, 25);
        registerButton.addActionListener(this);
        panel.add(registerButton);

        add(panel);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        String username = usernameField.getText();
        String password = String.valueOf(passwordField.getPassword());
        parent.addCredentials(username, password);
        JOptionPane.showMessageDialog(this, "Registration Successful!");
        dispose();
    }
}

// Class for Reset Password Form
class ResetPasswordForm extends JFrame implements ActionListener {
    private final JTextField usernameField;
    private final JPasswordField newPasswordField;
    private final Login parent;

    public ResetPasswordForm(Login parent) {
        this.parent = parent;

        setTitle("Reset Password Form");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(300, 200);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(null);

        JLabel userLabel = new JLabel("Username:");
        userLabel.setBounds(30, 30, 80, 25);
        panel.add(userLabel);

        usernameField = new JTextField(20);
        usernameField.setBounds(120, 30, 150, 25);
        panel.add(usernameField);

        JLabel passLabel = new JLabel("New Password:");
        passLabel.setBounds(30, 70, 100, 25);
        panel.add(passLabel);

        newPasswordField = new JPasswordField(20);
        newPasswordField.setBounds(120, 70, 150, 25);
        panel.add(newPasswordField);

        JButton resetButton = new JButton("Reset");
        resetButton.setBounds(100, 120, 100, 25);
        resetButton.addActionListener(this);
        panel.add(resetButton);

        add(panel);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        String username = usernameField.getText();
        String newPassword = String.valueOf(newPasswordField.getPassword());
        if (parent.credentials.containsKey(username)) {
            parent.addCredentials(username, newPassword);
            JOptionPane.showMessageDialog(this, "Password Reset Successful!");
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Username not found!");
        }
    }
}

// Class for the Online Test
class OnlineTestBegin extends JFrame implements ActionListener {
    private JLabel questionLabel;
    private final JRadioButton[] options;
    private JButton nextButton, submitButton;
    private final ButtonGroup optionGroup;
    private int count = 0, current = 0;

    public OnlineTestBegin(String username) {
        setTitle("Online Test - Welcome " + username);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        add(panel);

        questionLabel = new JLabel();
        panel.add(questionLabel);

        options = new JRadioButton[4];
        optionGroup = new ButtonGroup();
        for (int i = 0; i < 4; i++) {
            options[i] = new JRadioButton();
            optionGroup.add(options[i]);
            panel.add(options[i]);
        }

        nextButton = new JButton("Next");
        submitButton = new JButton("Submit");
        nextButton.addActionListener(this);
        submitButton.addActionListener(this);
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(nextButton);
        buttonPanel.add(submitButton);
        panel.add(buttonPanel);

        setQuestion();

        setVisible(true);
    }

    private void setQuestion() {
        options[0].setSelected(true);
        if (current == 0) {
            questionLabel.setText("Q1: Which of the following is not OOPS concept in Java?");
            options[0].setText("Inheritance");
            options[1].setText("Encapsulation");
            options[2].setText("Polymorphism");
            options[3].setText("Compilation");
        }
        // Add more questions here
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == nextButton) {
            if (current < 9) {
                current++;
                setQuestion();
            } else {
                JOptionPane.showMessageDialog(this, "You have reached the end of the test. Please submit your answers.");
            }
        } else if (ae.getSource() == submitButton) {
            // Evaluate answers and show result
            JOptionPane.showMessageDialog(this, "Test submitted. You scored: " + count);
        }
    }
}
