class NumberGameGUI2 implements Runnable {
    NumberGameGUI$2() {
    }
 
    public void run() {
       new NumberGameGUI();
    }
 }
 