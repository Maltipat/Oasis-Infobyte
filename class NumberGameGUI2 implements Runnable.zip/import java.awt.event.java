import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class NumberGameGUI1 implements ActiostenernLi {
   NumberGameGUI$1(NumberGameGUI var1) {
      this.this$0 = var1;
   }

   public void actionPerformed(ActionEvent var1) {
      this.this$0.checkGuess();
   }
}