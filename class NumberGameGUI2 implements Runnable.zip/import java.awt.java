import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.Random;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class NumberGameGUI {
   private JFrame frame = new JFrame("Number Game");
   private JLabel titleLabel;
   private JLabel label;
   private JTextField textField;
   private JButton submitButton;
   private int targetNumber;
   private int attempts;
   private int maxAttempts;
   private int score;

   public NumberGameGUI() {
      this.frame.getContentPane().setBackground(new Color(240, 240, 240));
      this.titleLabel = new JLabel("Welcome to the Number Guessing Game!");
      this.titleLabel.setFont(new Font("Arial", 1, 18));
      this.titleLabel.setForeground(new Color(70, 130, 180));
      this.label = new JLabel("Enter your guess (1-100):");
      this.label.setFont(new Font("Arial", 0, 14));
      this.textField = new JTextField(10);
      this.submitButton = new JButton("Submit");
      this.submitButton.setBackground(new Color(70, 130, 180));
      this.submitButton.setForeground(Color.WHITE);
      this.submitButton.setFocusPainted(false);
      this.targetNumber = this.generateRandomNumber();
      this.maxAttempts = 5;
      this.attempts = 0;
      this.score = 0;
      this.submitButton.addActionListener(new NumberGameGUI$1(this));
      JPanel var1 = new JPanel();
      var1.setLayout(new GridLayout(4, 1));
      var1.setBackground(new Color(240, 240, 240));
      var1.add(this.titleLabel);
      var1.add(this.label);
      var1.add(this.textField);
      var1.add(this.submitButton);
      this.frame.add(var1);
      this.frame.setDefaultCloseOperation(3);
      this.frame.setSize(300, 200);
      this.frame.setLocationRelativeTo((Component)null);
      this.frame.setVisible(true);
   }

   private int generateRandomNumber() {
      Random var1 = new Random();
      return var1.nextInt(100) + 1;
   }

   private void checkGuess() {
      int var1;
      try {
         var1 = Integer.parseInt(this.textField.getText());
      } catch (NumberFormatException var3) {
         JOptionPane.showMessageDialog(this.frame, "Please enter a valid number.");
         return;
      }

      ++this.attempts;
      if (var1 == this.targetNumber) {
         JOptionPane.showMessageDialog(this.frame, "Congratulations! You guessed the correct number.");
         ++this.score;
      } else if (this.attempts < this.maxAttempts) {
         String var2 = var1 < this.targetNumber ? "Too low! Try a higher number." : "Too high! Try a lower number.";
         JOptionPane.showMessageDialog(this.frame, var2);
      } else {
         JOptionPane.showMessageDialog(this.frame, "Sorry! You've used all your attempts. The correct number was " + this.targetNumber);
      }

      if (this.attempts < this.maxAttempts) {
         this.targetNumber = this.generateRandomNumber();
         this.textField.setText("");
      } else {
         this.showScore();
      }

   }

   private void showScore() {
      JOptionPane.showMessageDialog(this.frame, "Your final score is: " + this.score);
      int var1 = JOptionPane.showConfirmDialog(this.frame, "Do you want to play again?", "Play Again", 0);
      if (var1 == 0) {
         this.resetGame();
      } else {
         this.frame.dispose();
      }

   }

   private void resetGame() {
      this.targetNumber = this.generateRandomNumber();
      this.attempts = 0;
      this.score = 0;
      this.textField.setText("");
   }

   public static void main(String[] var0) {
      SwingUtilities.invokeLater(new NumberGameGUI$2());
   }
}
